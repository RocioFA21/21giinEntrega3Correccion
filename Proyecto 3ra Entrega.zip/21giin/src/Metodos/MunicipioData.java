package Metodos;


import Forms.municipios;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class MunicipioData {
       
    public void municipioData(char operation, String nombre, String categoria, String id)
    {
        
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        
        // i for insert
        if(operation == 'i')
        {
            try {
                ps = (PreparedStatement) con.prepareStatement("INSERT INTO municipio (nombre, categoria) VALUES (?, ?) ");
                ps.setString(1, nombre);
                ps.setString(2, categoria);
                
                if(ps.executeUpdate () > 0){
                    JOptionPane.showMessageDialog(null, "Nuevo Municipio Registrado");
                }
            } catch (SQLException ex) {
                Logger.getLogger(MunicipioData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void llenarTablaMunicipio(JTable table, String valueToSearch)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        try {
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM municipio WHERE CONCAT(nombre, categoria) LIKE ?");
            ps.setString(1, "%"+valueToSearch+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while(rs.next()){
                row = new Object[3];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                
                model.addRow(row);
                
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(municipios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
}



















