/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Metodos;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JComboBox;



/**
 *
 * @author Rocio
 */
public class cargar_comboboxCuentadante {
    Connection con = MyConnection.getConnection();
    PreparedStatement ps;
    String jComboID;
        
    public void consultar_cunetadante(JComboBox jComboBox_UsuarioCuent){
        
        try {
            //consulta sql
            ps = (PreparedStatement) con.prepareStatement("SELECT id,nombre FROM usuarios");
            
            //ejecutamos la consulta
            ResultSet rs = ps.executeQuery();
            
            //llenar el combobox
            jComboBox_UsuarioCuent.addItem("Sleccione una opcion");
            
            while(rs.next()){
                jComboBox_UsuarioCuent.addItem(rs.getString("id")+" - "+rs.getString("nombre"));
                jComboID = rs.getString("id");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(cargar_comboboxCuentadante.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
}
