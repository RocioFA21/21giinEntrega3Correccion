package Metodos;


import Forms.usuarios;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class UsuarioData {

    public void usuarioData(char operation, String nombre, String clave, String tipo, String id)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        
        // i for insert
        if(operation == 'i')
        {
            try {
                ps = (PreparedStatement) con.prepareStatement("INSERT INTO usuarios (nombre, clave, tipo) VALUES (?, ?, ?) ");
                ps.setString(1, nombre);
                ps.setString(2, clave);
                ps.setString(3, tipo);
                
                if(ps.executeUpdate () > 0){
                    JOptionPane.showMessageDialog(null, "Nuevo Usuario Registrado");
                }
            } catch (SQLException ex) {
                Logger.getLogger(UsuarioData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void llenarTablaUsuarios(JTable table, String valueToSearch)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        try {
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM usuarios WHERE CONCAT(nombre, clave, tipo) LIKE ?");
            ps.setString(1, "%"+valueToSearch+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while(rs.next()){
                row = new Object[4];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                
                model.addRow(row);
                
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(usuarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
}



















