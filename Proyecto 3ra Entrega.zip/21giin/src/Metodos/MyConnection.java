package Metodos;


import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
        
    public static Connection getConnection()
    {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://rds-21giin.c0bc3kbxuj7d.us-east-1.rds.amazonaws.com:3306/proyectodb","admin","admin1234");
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());

        }
        return con;
    }
}
