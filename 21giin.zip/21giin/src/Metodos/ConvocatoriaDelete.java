package Metodos;


import Forms.convocatorias;
import Forms.municipios;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class ConvocatoriaDelete {

    public void convoD(char operation, String nombre, String clave, String tipo, String id)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        // d for delete
        if(operation == 'd')
        {
            try {
                ps = (PreparedStatement) con.prepareStatement("DELETE FROM convocatoria WHERE id=?;");
                ps.setString(1, id);
                
                if(ps.executeUpdate () > 0){
                    JOptionPane.showMessageDialog(null, "Convocatoria Eliminado");
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConvocatoriaData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void llenarTablaConvocatoria(JTable table, String valueToSearch)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        try {
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM convocatoria WHERE CONCAT(nombre, categoria) LIKE ?");
            ps.setString(1, "%"+valueToSearch+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while(rs.next()){
                row = new Object[3];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                
                model.addRow(row);
                
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(convocatorias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
}



















