package Metodos;


import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
        
    public static Connection getConnection()
    {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://sql4.freemysqlhosting.net:3306/sql4465308","sql4465308","v4RJ7WHvry");
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());

        }
        return con;
    }
}
