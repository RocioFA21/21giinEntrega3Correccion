package Metodos;


import Forms.convocatorias;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.Date;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

public class ConvocatoriaData {
       
    public void convoData(char operation, String nombre, String descrip, String estado, String documentos, String id)
    {
        
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        
        java.util.Date date=new java.util.Date();
        java.sql.Date sqlDate=new java.sql.Date(date.getTime());
        java.sql.Timestamp sqlTime=new java.sql.Timestamp(date.getTime());    
        
        String fechaC = null;
        
        // i for insert
        if(operation == 'i')
        {            
            try {
                ps = (PreparedStatement) con.prepareStatement("INSERT INTO convocatoria (nombre, descrip, fechaA, fechaC, estado, documentos) VALUES (?, ?, ?, ?, ?, ?) ");
                ps.setString(1, nombre);
                ps.setString(2, descrip);
                ps.setDate(3, sqlDate);
                ps.setString(4, fechaC);
                ps.setString(5, estado);
                ps.setString(6, documentos);
                
                if(ps.executeUpdate () > 0){
                    JOptionPane.showMessageDialog(null, "Nueva Convocatoria Abierta");
                }
            } catch (SQLException ex) {
                Logger.getLogger(ConvocatoriaData.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public void llenarTablaConvocatoria(JTable table, String valueToSearch)
    {
        Connection con = MyConnection.getConnection();
        PreparedStatement ps;
        try {
            ps = (PreparedStatement) con.prepareStatement("SELECT * FROM convocatoria WHERE CONCAT(nombre, descrip, fechaA, fechaC, estado, documentos) LIKE ?");
            ps.setString(1, "%"+valueToSearch+"%");
            
            ResultSet rs = ps.executeQuery();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            Object[] row;
            
            while(rs.next()){
                row = new Object[7];
                row[0] = rs.getInt(1);
                row[1] = rs.getString(2);
                row[2] = rs.getString(3);
                row[3] = rs.getString(4);
                row[4] = rs.getString(5);
                row[5] = rs.getString(6);
                row[6] = rs.getString(7);
                
                model.addRow(row);
                
            }
        } catch (SQLException ex) {
            java.util.logging.Logger.getLogger(convocatorias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
    }
}



















